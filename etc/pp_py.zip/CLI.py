#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 19:47:52 2024

@author: won
"""

class CLI:
    