#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 16:15:15 2024

@author: won
"""

mess = input().split()
print(f"col: {int(mess[0])}, row: {int(mess[1])}, level: {int(mess[2])}")